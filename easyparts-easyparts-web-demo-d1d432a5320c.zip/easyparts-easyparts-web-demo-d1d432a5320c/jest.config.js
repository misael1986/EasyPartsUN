module.exports = {
    testResultsProcessor: "jest-sonar-reporter",
    verbose: true,
};
